/* Str5.C */
/* Mostra o uso da aritm�tica com endere�os */
#include <stdio.h>
#include <stdlib.h>

int main()				
{
	char salute[]="Sauda��es, ";
	char nome[80];
	printf("Digite o seu nome: "); 
	gets(nome);
	printf("%s%s\n", salute, nome + 5);
	system("PAUSE");	
	return 0;			
}
