/* Diag.C */
/* Move o cursor na diagonal */
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int main()
{
	printf("\x1B[2J");
	while(getche()!='.')
		printf("\x1B[B");
	system("pause");
	return 0;
}
