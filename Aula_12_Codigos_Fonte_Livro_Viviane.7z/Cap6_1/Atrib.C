/* Atrib.C */
/* Troca atributos de caracteres */
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

#define NORMAL "\x1B[0m"
#define INTEN "\x1B[1m"
#define AZUL "\x1B[4m"
#define PISCA "\x1B[5m"
#define REV "\x1B[7m"

int main()
{
	printf("\n\n");
	printf("Normal %s Piscante %s Normal \n\n",PISCA,NORMAL);
	printf("Normal %s Negrito %s Normal \n\n",INTEN,NORMAL);
	printf("Normal %s Azul %s Normal \n\n",AZUL,NORMAL);
	printf("Normal %s Reverso %s Normal \n\n",REV,NORMAL);
	printf(" %s %s Reverso e Piscante %s",PISCA,REV,NORMAL);
	system("pause");
	return 0;
}
