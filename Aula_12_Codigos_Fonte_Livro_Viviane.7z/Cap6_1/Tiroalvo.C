/* Tiroalvo.C */
/* Usa controle de tela ANSI.SYS */
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

#include "Ansi.h"

#define BEEP printf("\x7")
#define SOBE 72
#define DESCE 80
/* Prot�tipos */
void atualiza(int ,int ,int );
void posin(int);
void linha_dir(void);
int alvo(void);
void dispara(int);
void bum(int);
void apagalvo(int);
/* Fim dos prot�tipos */

int main ( )
{
	int municao=15,disparos=0,pontos=0,i,j;
	NORMAL; LIMPA;
	POS_C(12,26);printf("*** TIRO AO ALVO ***");
	POS_C(15,15) ;
	printf("UTILIZE AS SETAS PARA MOVIMENTAR O ATIRADOR");
	POS_C(18,21);printf("E QUALQUER OUTRA PARA DISPARAR.");
	POS_C(23,20);printf("PRESSIONE <ENTER> PARA CONTINUAR");
	getch();LIMPA;
	POS_C(24,4);REV;printf("MUNICAO: ");
	POS_C(24,31);printf("DISPAROS: ");
	POS_C(24,59);printf("PONTOS: ");
	NORMAL;
	atualiza(municao,disparos,pontos);
	while(municao) {
		linha_dir();		/* imprime linha direita */
		i= alvo();			/* imprime alvo			 */
		j=22;posin(j);		/* posi��o inicial		 */
		while(getch()==0) 
		{					/* usu�rio joga at� atirar */
			switch(getch()) 
			{
				case SOBE: j=(j<2) ? 22:j-1;break;
				case DESCE: j=(j>21) ? 1:j+1;break;
			}
			posin(j);
		}
		disparos++; municao--;
		dispara(j);			/* simula disparo */
		if(j==i+1) 
		{					/* acertou */
			bum(i+1) ;
			pontos++;
			municao=((pontos%5)==0) ? municao+2:municao;
		}
		apagalvo(i);
		atualiza(municao,disparos,pontos);
	}
	POS_C(10,25);printf("* * * FIM * * *");
	getch();
 	system("pause");
	return 0;
}

void atualiza(int m,int d,int p)
{
	REV;PISCA;
	POS_C(24,13);printf(" %02d",m);
	if(!m) BEEP;
	POS_C(24,40);printf(" %03d",d);
	POS_C(24,66);printf(" %03d",p);
	NORMAL;
}
void posin(int j)
{
	REV;
	POS_C(j,78);printf("\xDB");
	NORMAL;
}
void linha_dir()
{
	int i;
	for(i=1;i<23;i++) 
	{
		POS_C(i,78);
		printf("\xDB");
	}
}
int alvo() 
{
	int i;
	i=rand()%21;
	POS_C(i , 1) ;printf("\xDB") ;
	POS_C(i+2, 1);printf("\xDB") ;
	return i;
}
void dispara(int j)
{
	int i;
	for(i=76; i>0 ; i-=2) 
	{
		delay(40);
		POS_C(j,i);printf("\xDC");
		POS_C(j,i);printf(" ");
	}
}
void bum(int j)
{
	int i;
	for(i=0;i<15;i++) 
	{
		delay(40);
		POS_C(j,i);printf(" BUUUMMM !!!");
		delay(40);
		POS_C(j,i);printf("            ");
	}
}
void apagalvo(int j)
{
	POS_C(j,1) ;printf(" ") ;
	POS_C(j+2,1);printf(" ");
}

