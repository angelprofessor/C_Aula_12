/* Maiusc.C */
/* Converte para letras mai�sculas */
#include <stdio.h> /* para getchar(), EOF */
#include <stdlib.h>

int main()				
{
	int ch;
	/* EOF � uma constante definida no arquivo stdio.h */
	while (( ch=getchar()) != EOF) /*pressione Ctrl+Z para terminar */
	{
		/* Converte para letras mai�sculas */
		printf("%c",(unsigned char) (ch >= 'a' && ch <='z' ? 
ch - 'a' + 'A' : ch));
	}
	
	return 0;			
}
