/* AndOp.C */
/* Mostra o uso do operador & para testar um bit */
#include <stdio.h>
#include <stdlib.h>
int main()
{
	unsigned char far *p = (unsigned char far *) 0x417;

	if(*p & 0x20 ) /* testa se bit 5 est� ligado */
		puts("Num Lock ligado.");
	else
		puts("Num Lock desligado.");
	system("pause");
	return 0;
}
