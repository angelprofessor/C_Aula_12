/* PtrFar.C */
/* Mostra o uso de ponteiros far */
/* Acesso a mem�ria de video CGA */
/* Usa o compilador Turbo C++    */

int main()
{
	unsigned char far *p = (unsigned char far *) 0xB8000000;
	*p ='A';

	return 0;
}
