/* AndEQOp.C */
/* Mostra o uso do operador &= para zerar um bit */
#include <stdio.h>
#include <stdlib.h>
int main()
{
	unsigned char far *p = (unsigned char far *) 0x417;

	*p &= 0xDF; /* 1 1 0 1 1 1 1 1 � desliga num lock*/

	system("pause");
	return 0;
}
