/* OrEqOp.C */
/* Mostra o uso do operador |= para ligar um bit */
#include <stdio.h>
#include <stdlib.h>
int main()
{
	unsigned char far *p = (unsigned char far *) 0x417;

	*p |= 0x20; /* 0 0 1 0 0 0 0 0 � liga num lock*/

	system("pause");
	return 0;
}

