/*FileCont1.C */
/*Conta caracteres do arquivo em modo bin�rio */
#include <stdio.h> /* define FILE */
#include <stdlib.h>

int main(int argc,char **argv)
{
	FILE *fptr;  /* ponteiro para arquivo */
	short int ch;
	int cont=0;

	if(argc != 2)
	{
		puts("Forma de uso: C:\\>FileCont nomearq");
		exit(1);
	}

	if( (fptr = fopen(argv[1],"rb")) == NULL)
	{
		puts("N�o foi poss�vel abrir o arquivo");
		exit(1);
	}
	
	while((ch=fgetc(fptr)) != EOF)  /*L� um caractere do arquivo */
		cont++;          /*incrementa contador de caracteres */
	printf("O tamanho do arquivo � %d bytes.\n", cont);
	fclose(fptr);

    return 0;
}
