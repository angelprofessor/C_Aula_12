/*Diagonal21.C */
/*Desenha duas linhas diagonais cruzadas usando ou l�gico */
#include <stdio.h>
#include <stdlib.h>
	
int main()				
{
	int lin, col;
	for(lin=1; lin < 25 ; lin++)/* passo da descida */
	{
        for(col=1; col < 25; col++)/* passo da largura */
		if(lin==col || col== 25-lin)/*estamos na diagonal 1 ou 2 ? */
			printf("\xDB"); /* sim, desenha bloco escuro */
		else
			printf("\xB0");/* n�o, desenha bloco claro */
	  	printf("\n");/* pula de linha */
      	}
	system("PAUSE");	
	return 0;			
}

