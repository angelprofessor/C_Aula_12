/*Diagonal.C */
/*Desenha uma linha diagonal na tela */
#include <stdio.h>
#include <stdlib.h>
	
int main()				
{
	int lin, col;
	for(lin=1; lin < 25 ; lin++)/* passo da descida */
	{
        	for(col=1; col < 25; col++)/* passo da largura */
			if(lin==col) /* estamos na diagonal ? */
				printf("\xDB"); /* sim, desenha bloco escuro */
			else
				printf("\xB0");/* n�o, desenha bloco claro */
	   	printf("\n");/* pula de linha */
      	}
	system("PAUSE");	
	return 0;			
}
