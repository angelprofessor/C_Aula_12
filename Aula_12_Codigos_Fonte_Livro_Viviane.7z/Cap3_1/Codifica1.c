/* Codifica1.c */
/* Codifica a entrada digitada */
#include <stdio.h>
#include <stdlib.h>
#include <conio.h> /* para getch() */
int main()				
{
	unsigned char ch;
	for( ; (ch=getch()) != 'X' ; )
		printf("%c", ch +1);

	printf("\n");
	system("PAUSE");	
    return 0;			
}



