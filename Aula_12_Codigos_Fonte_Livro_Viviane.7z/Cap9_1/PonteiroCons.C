/* PonteiroCons.C */
/* Mostra ponteiros constantes */
#include <stdio.h>  
#include <stdlib.h> 

int main()
{
	int i,j,k;

	printf("Endere�o de i = %p\n", &i); /* %p para ponteiros */
	printf("Endere�o de j = %p\n", &j);
	printf("Endere�o de k = %p\n", &k);
	
	system("PAUSE");	
	return 0;			
}
