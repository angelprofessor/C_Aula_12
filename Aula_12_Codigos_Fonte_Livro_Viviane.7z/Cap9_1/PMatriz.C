/* PMatriz.C */
/* Imprime os elementos de uma matriz usando nota��o ponteiro */
#include <stdio.h>  
#include <stdlib.h> 

int main()
{
	static int M[5]={92,81,70,69,58};
	int i;
	for(i=0; i<5; i++)
		printf("%d\n", *(M + i)); /* Nota��o ponteiro */

	system("PAUSE");	
	return 0;		
}
