/* BQsortStruct.C */
/* Algoritmo qsort e binarySearch com estruturas */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* Exemplo com estrutura */
struct est_pop 
{ 
    char estado[16];
    int pop; /* popula��o */
};
 
/* qsort - fun��o para comparar struct por popula��o (membro int) */
int struct_cmp_por_pop(const void *a, const void *b)
{
    struct est_pop *pa = (struct est_pop *)a;
    struct est_pop *pb = (struct est_pop *)b;
    return pa->pop - pb->pop;	/* Retorna neg. se a<b e pos. se a>b */
} 
 
/* qsort - fun��o para comparar struct por estado (membro C-string) */
int struct_cmp_por_estado(const void *a, const void *b)
{
    struct est_pop *pa = (struct est_pop *)a;
    struct est_pop *pb = (struct est_pop *)b;
    return strcmp(pa->estado, pb->estado);
} 

int main()
{
	unsigned int tamanho, i;
	struct est_pop structs[] = /* popula��o dividido por 1000 */
		{{"Sergipe   ", 1968}, {"Bahia     ", 13815}, 
             {"Piau�     ", 3007}, {"Acre      ", 670}, 
             {"Rond�nia  ",1535 }, {"Tocantins ", 1306 }};

	tamanho = sizeof(structs) / sizeof(struct est_pop);
	/* imprime matriz de estruturas original */
	puts("Estrutura Original");
	for(i=0; i<tamanho; i++)
		printf("[ estado: %s \t popula��o: %6d000 ]\n",
structs[i].estado, structs[i].pop);
 	puts("===============================================");
	/* ordena usando a fun��o qsort */
	qsort(structs, tamanho, sizeof(struct est_pop), 
					   struct_cmp_por_pop);
 	/* imprime matriz de estruturas ordenada */
	puts("Estrutura ordenada por popula��o");
	for(i=0; i<tamanho; i++)
		printf("[ estado: %s \t popula��o: %6d000 ]\n", 
			structs[i].estado, structs[i].pop);
	puts("===============================================");
	puts("Estrutura ordenada por estado");
	/* reordena usando a fun��o qsort */
	qsort(structs, tamanho, sizeof(struct est_pop), 
					struct_cmp_por_estado);    
	/* imprime matriz de estruturas ordenada */
	for(i=0; i<tamanho; i++)
        printf("[ estado: %s \t popula��o: %6d000 ]\n", 
			structs[i].estado, structs[i].pop);
 	puts("===============================================");
	system("pause");
    	return 0;
}
