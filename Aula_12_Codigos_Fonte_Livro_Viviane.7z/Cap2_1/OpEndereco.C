/* OpEndereco.C */
#include <stdio.h>
#include <stdlib.h>
int main()				
{
	int n;
	n=2;
	printf("Valor=%d, endereco=%p\n",n,&n);
	system("PAUSE");	
    	return 0;			
}
