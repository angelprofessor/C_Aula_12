/* OpRel.C */
/* Mostra operadores relacionais */
#include <stdio.h>
#include <stdlib.h>
int main()				
{
    int Verdadeiro, Falso;

	Verdadeiro = (15  < 20);
	Falso      = (15 == 20);

	printf("Verdadeiro %d\n", Verdadeiro);
	printf("Falso      %d\n", Falso);

	system("PAUSE");	
    	return 0;		

}

