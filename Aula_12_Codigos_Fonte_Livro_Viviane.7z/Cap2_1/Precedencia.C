/* Precedencia.C */
/* Mostra a preced�ncia dos operadores relacionais */
#include <stdio.h>
#include <stdlib.h>
int main()				
{
    	printf("O valor da express�o 4 + 1 < 3 � %d\n", 4+1<3);
	printf("O valor da express�o 2 < 1 + 3 � %d\n", 2<1+3);

	system("PAUSE");	
    	return 0;
}
