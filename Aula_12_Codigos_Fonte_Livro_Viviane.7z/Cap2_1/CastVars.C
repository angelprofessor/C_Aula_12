/* CastVars.C */
/* Mostra o operador de convers�o de tipo */
#include <stdio.h>
#include <stdlib.h>

int main()				
{
    int VarInt=2000000000;
    int Dez =10;
    VarInt = ((double)VarInt * Dez)/Dez; /* converte p/double */
    printf("\nVarInt = %d\n", VarInt);	 /* resposta correta  */	
    system("PAUSE");	
    return 0;	
}



