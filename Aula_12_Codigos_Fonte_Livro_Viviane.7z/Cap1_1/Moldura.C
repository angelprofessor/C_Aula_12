/* Moldura.C */
/*Desenha moldura*/
#include <stdio.h> /* para printf() */
#include <stdlib.h>/* para system() */
int main()				
{
	system("cls");/*Limpa a tela*/
	printf("\n\n");
	printf("\n\t\xC9\xCD\xBB");
	printf("\n\t\xBA \xBA");
	printf("\n\t\xC8\xCD\xBC");
	printf("\n\n");
	system("PAUSE");	
    	return 0;			
}
