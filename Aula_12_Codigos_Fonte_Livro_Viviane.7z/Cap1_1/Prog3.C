/* Prog3.C */
#include <stdio.h> /* para printf() */
#include <stdlib.h>/* para system() */
int main()
{
    	printf("%s est� a %d milh�es de milhas\ndo sol.\n", "Venus", 67 );
	system("PAUSE");
	return 0;
}

