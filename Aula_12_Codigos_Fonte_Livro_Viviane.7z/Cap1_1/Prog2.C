/* Prog2.C */
#include <stdio.h> /* para printf() */
#include <stdlib.h>/* para system() */
int main()
{
    	printf("Este � o n�mero %d.\n", 5 );
	system("PAUSE");
	return 0;
}
