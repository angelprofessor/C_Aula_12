#include <stdio.h>
#include <stdlib.h>
int main()
{
    	printf("Primeiro programa.");
	system("PAUSE");
	return 0;
}
