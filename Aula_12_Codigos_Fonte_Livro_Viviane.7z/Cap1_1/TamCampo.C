/* TamCampo.C */
/* Tamanho de campo com inteiros */
#include <stdio.h> /* para printf() */
#include <stdlib.h>/* para system() */
int main()				
{
	printf("Os alunos sao %2d.\n",350);
	printf("Os alunos sao %4d.\n",350);
	printf("Os alunos sao %5d.\n",350);
	system("PAUSE");	
   	return 0;			
}


