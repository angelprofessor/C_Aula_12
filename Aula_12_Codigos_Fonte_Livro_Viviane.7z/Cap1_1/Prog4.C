/* Prog4.C */
#include <stdio.h> /* para printf() */
#include <stdlib.h>/* para system() */
int main()
{
    	printf("A letra %c", 'J');
	printf(" pronuncia-se %s%c%c", "Jota",'.', '\n');

	system("PAUSE");
	return 0;
}

