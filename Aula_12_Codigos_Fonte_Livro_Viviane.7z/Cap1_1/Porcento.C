/* Porcento.C
 * Mostra a impress�o de %
 */
#include <stdio.h> /* para printf() */
#include <stdlib.h>/* para system() */
int main()				
{
	int reajuste = 10;
	
	printf("O reajuste foi de %d%%.\n",reajuste);
	system("PAUSE");	
    	return 0;			
}

